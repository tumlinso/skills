#!/usr/bin/env python3
"""Validate local atlas structure, references, hashes and evidence-state labels."""
from __future__ import annotations
import hashlib
import json
import re
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main() -> int:
    errors=[];checks=0
    def check(condition,message):
        nonlocal checks
        checks+=1
        if not condition:errors.append(message)
    try:obj=json.loads((ROOT/'manifest.json').read_text())
    except Exception as exc:print(str(exc),file=sys.stderr);return 2
    entries=obj['documents']+obj['sources'];known={d['id'] for d in entries}
    check(len(known)==len(entries),'Duplicate stable IDs')
    expected=set()
    expected |= {f'R{i:02}' for i in range(16)}
    expected |= {f'M{i:02}' for i in range(1,53)}
    expected |= {f'C{i:02}' for i in range(40)}
    expected |= {f'E{i:02}' for i in range(40)}
    expected |= {f'S{i:02}' for i in range(1,43)}
    expected |= {'A00','A01','A02'}
    check(known==expected,'Missing or unexpected document/source IDs')
    check(obj.get('gpu_measured') is False,'GPU measured flag is not false')
    check(obj.get('cuda_compiled') is False,'CUDA compiled flag is not false')
    for d in entries:
        path=(ROOT/d['path']).resolve()
        check(path.is_relative_to(ROOT),f"Unsafe path {d['path']}")
        check(path.exists(),f"Missing {d['path']}")
        if not path.exists():continue
        raw=path.read_bytes();text=raw.decode('utf-8')
        check(hashlib.sha256(raw).hexdigest()==d.get('sha256'),f"Hash mismatch {d['id']}")
        check(len(text.split())==d.get('words'),f"Word count mismatch {d['id']}")
        for ref in d.get('requires',[])+d.get('sources',[]):
            check(ref in known,f"Unknown dependency {ref} in {d['id']}")
        # Only the stable R/M/C/E/S scheme, not assembly registers or arbitrary numeric strings.
        for ref in set(re.findall(r'(?<![A-Za-z0-9_])(?:R\d{2}|M\d{2}|C\d{2}|E\d{2}|S\d{2})(?![A-Za-z0-9_])',text)):
            check(ref in known,f"Unknown prose reference {ref} in {d['id']}")
        if d.get('kind')=='experiment':check(d['status']=='NOT_RUN_ON_GPU',f"Unjustified experiment promotion {d['id']}")
    for p in ROOT.rglob('*.json'):
        if p.name=='VALIDATION.json':continue
        try:json.loads(p.read_text());checks+=1
        except Exception as exc:errors.append(f'{p.relative_to(ROOT)}: {exc}')
    for p in ROOT.rglob('*.jsonl'):
        for line_no,line in enumerate(p.read_text().splitlines(),1):
            if not line.strip():continue
            try:json.loads(line);checks+=1
            except Exception as exc:errors.append(f'{p.relative_to(ROOT)} line{line_no}: {exc}')
    full=(ROOT/obj['compendium']['path']).read_bytes()
    check(hashlib.sha256(full).hexdigest()==obj['compendium']['sha256'],'Compendium hash mismatch')
    tests=json.loads((ROOT/'ledger/CPU_TEST_RESULTS.json').read_text())
    check(tests.get('status')=='PASS','CPU semantic suite is not PASS')
    check(tests.get('gpu_measured') is False,'CPU test report claims GPU measurement')
    check(tests.get('assertions',0)>0,'No CPU assertions recorded')
    for p in ROOT.rglob('*.md'):
        t=p.read_text()
        check(not re.search(r'POPC\s*14\b',t),f'Known incorrect POPC prior in {p.name}')
    result={'status':'PASS' if not errors else 'FAIL','checks':checks,'errors':errors,
            'validation_scope':'local artifact integrity and CPU semantic-record presence; not GPU performance',
            'gpu_measured':False,'cuda_compiled':False}
    (ROOT/'ledger/VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return 1 if errors else 0
if __name__=='__main__':raise SystemExit(main())
