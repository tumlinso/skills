#!/usr/bin/env python3
"""Refresh local document metadata and the archival full Markdown guide."""
from __future__ import annotations
import collections
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main() -> None:
    p=ROOT/'manifest.json'; obj=json.loads(p.read_text(encoding='utf-8'))
    for d in obj['documents']+obj['sources']:
        path=(ROOT/d['path']).resolve()
        if not path.is_relative_to(ROOT): raise ValueError(f"Unsafe path: {d['path']}")
        raw=path.read_bytes(); text=raw.decode('utf-8')
        d.update(words=len(text.split()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    counts=collections.Counter(d['kind'] for d in obj['documents'])
    obj['counts']=dict(counts)
    obj['counts']['source']=len(obj['sources'])
    obj['unique_document_words']=sum(d['words'] for d in obj['documents'])
    obj['source_capsule_words']=sum(d['words'] for d in obj['sources'])
    testfile=ROOT/'ledger/CPU_TEST_RESULTS.json'
    obj['validation_status']={'gpu_measured':False,'cuda_compiled':False}
    if testfile.exists():
        test=json.loads(testfile.read_text())
        obj['validation_status']['cpu_semantics']={k:test[k] for k in ['status','assertions'] if k in test}
        obj['validation_status']['cpu_semantics']['test_groups']=len(test.get('groups',[]))
    # An explicit stable ID anchor makes the archival compendium navigable.
    order={'index':0,'reference':1,'mechanism':2,'composition':3,'experiment':4}
    docs=sorted(obj['documents'],key=lambda d:(order.get(d['kind'],9),d['id']))
    full=['# V100 / SXM2 Software Circuit-Bending Atlas\n',
          '**Research/synthesis date:** 2026-10-03. **Edition:** 1.0.\n',
          'This is the archival all-in-one view. For selective model context, use START_HERE.md, NEED_INDEX.md and tools/read_atlas.py in the ZIP package.\n',
          'Evidence, original hypotheses and unresolved details remain separately labeled. No GPU timings, CUDA compilation or novel speedups were measured during authoring.\n',
          '## Contents\n']
    for d in docs: full.append(f"- [{d['id']} — {d['title']}](#{d['id'].lower()})\n")
    for d in docs:
        full += [f"\n---\n\n<a id=\"{d['id'].lower()}\"></a>\n\n",(ROOT/d['path']).read_text(encoding='utf-8')]
    full += ['\n---\n\n# Source capsules\n']
    for s in obj['sources']:
        full += [f"\n<a id=\"{s['id'].lower()}\"></a>\n\n",(ROOT/s['path']).read_text(encoding='utf-8'),'\n']
    for path in ['ledger/CORRECTIONS.md','ledger/OPEN_QUESTIONS.md','ledger/SCOPE.md','ledger/LEGACY_SCOPE.md','ledger/MAINTENANCE.md']:
        full += ['\n---\n\n',(ROOT/path).read_text(encoding='utf-8')]
    if testfile.exists():
        t=json.loads(testfile.read_text())
        full += ['\n---\n\n# Local semantic validation\n',f"\nCPU status: {t.get('status')}. Assertions: {t.get('assertions')}. Test groups: {len(t.get('groups',[]))}.\n",
                 '\nThese validate algebra, encoding and logical coordinate mappings, not actual tensor rounding, memory coherence, generated SASS or performance. GPU experiments remain unrun.\n']
    text='\n'.join(full)
    (ROOT/'V100_ATLAS_FULL.md').write_text(text,encoding='utf-8')
    obj['compendium']={'path':'V100_ATLAS_FULL.md','words':len(text.split()),'sha256':hashlib.sha256(text.encode()).hexdigest()}
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'counts':obj['counts'],'unique_document_words':obj['unique_document_words'],'full_words':obj['compendium']['words']}))
if __name__=='__main__':main()
